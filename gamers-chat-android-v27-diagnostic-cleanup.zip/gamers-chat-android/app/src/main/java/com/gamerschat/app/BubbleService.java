package com.gamerschat.app;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.webkit.WebViewClient;
import android.widget.TextView;

// Step 2 of the floating-bubble feature: a Foreground Service that
// draws a small circular bubble on top of whatever else is on
// screen, including a running game. This is the actual visual thing
// the whole Android-wrapper effort was for.
//
// Why a Service and not just an Activity: an Activity's window
// disappears the moment you switch to another app (that's the
// entire point of "leaving the game" we're trying to avoid). A
// Service has no window of its own by default, but CAN create and
// manage its own WindowManager-level view that persists across app
// switches -- that persistent view is the bubble.
public class BubbleService extends Service {

    private static final String CHANNEL_ID = "voxx_chat_bubble_channel";
    private static final int FOREGROUND_NOTIFICATION_ID = 2001;

    private WindowManager windowManager;
    private View bubbleView;
    private WindowManager.LayoutParams bubbleParams;

    // The small expandable panel shown when the bubble is tapped.
    // Kept separate from bubbleView since it's shown/hidden
    // independently and needs to be focusable (to accept keyboard
    // input), unlike the bubble itself which deliberately isn't.
    private View panelView;
    private WindowManager.LayoutParams panelParams;
    private boolean isPanelShowing = false;
    private EditText codeInputField;
    private LinearLayout requestStatusRow;

    // The hidden WebView that actually runs your real, already-working
    // PWA in the background -- this is what makes the bubble able to
    // reflect and control REAL call state instead of being a
    // disconnected native mockup. It's added to the window manager
    // with zero size (invisible) rather than not attached at all,
    // because an unattached WebView on some Android versions gets
    // throttled/suspended much more aggressively.
    private WebView hiddenWebView;

    // Tracks what the bubble should currently show. Updated by
    // JS calling back into bridgeToAndroid.updateBubbleState(...).
    private volatile String currentCallState = "idle"; // idle | ringing | in_call

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Android requires a Foreground Service to show a persistent
        // notification -- this is a real Android platform rule, not
        // something we're choosing, and it's what makes the service
        // (and therefore the bubble) allowed to keep running even
        // when the app itself isn't in the foreground.
        //
        // The explicit type argument (matching the manifest's
        // foregroundServiceType="specialUse") is required on Android
        // 10+ alongside the manifest declaration -- omitting it here
        // can still throw on some API levels even with the manifest
        // entry present.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    FOREGROUND_NOTIFICATION_ID,
                    buildForegroundNotification(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            );
        } else {
            startForeground(FOREGROUND_NOTIFICATION_ID, buildForegroundNotification());
        }

        if (bubbleView == null) {
            showBubble();
        }

        if (hiddenWebView == null) {
            setupHiddenWebView();
        }

        // TEMPORARY: handles the test buttons on OverlayPermissionActivity,
        // letting us verify the bubble's appearance-changing logic
        // works correctly without needing a second device or relying
        // on the invisible WebView's JS to fire. This bypasses the
        // WebView/JS bridge entirely -- it's a direct test of the
        // native side only.
        if (intent != null && "TEST_STATE_UPDATE".equals(intent.getAction())) {
            String testState = intent.getStringExtra("state");
            if (testState != null) {
                updateBubbleAppearance(testState);
            }
        }

        // If Android kills this service to free memory, restart it
        // with the same intent rather than leaving the bubble gone
        // silently.
        return START_STICKY;
    }

    private static final String PREFS_NAME = "voxx_chat_shared_prefs";
    private static final String PREF_DEVICE_ID = "device_id";

    // The real fix for the "bubble never sees real requests" bug:
    // the main TWA app runs inside actual Chrome (via Custom Tabs),
    // while this bubble uses a raw android.webkit.WebView -- these
    // are two completely separate storage engines with no shared
    // localStorage between them, confirmed via Chrome's own official
    // documentation on Custom Tabs vs WebView storage isolation.
    // Neither engine can be silently pointed at the other's storage.
    //
    // Instead, native Android's own SharedPreferences becomes the
    // single source of truth: this bubble generates/reads the
    // deviceId from there, and injects it into ITS OWN WebView's
    // localStorage before the page runs (see onPageStarted below).
    private String getOrCreateSharedDeviceId() {
        android.content.SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String deviceId = prefs.getString(PREF_DEVICE_ID, null);
        if (deviceId == null) {
            deviceId = java.util.UUID.randomUUID().toString();
            prefs.edit().putString(PREF_DEVICE_ID, deviceId).apply();
        }
        return deviceId;
    }

    private void showBubble() {
        if (!Settings.canDrawOverlays(this)) {
            // Safety check: if permission was somehow revoked after
            // this service started, don't attempt to draw -- doing so
            // would throw and crash the whole service.
            stopSelf();
            return;
        }

        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        // A real circle (not a square with a background color) using
        // a GradientDrawable shaped as an oval -- with equal width
        // and height, an oval renders as a perfect circle.
        GradientDrawable circleShape = new GradientDrawable();
        circleShape.setShape(GradientDrawable.OVAL);
        circleShape.setColor(Color.parseColor("#3ddc97"));

        TextView bubble = new TextView(this);
        bubble.setText("🎙️");
        bubble.setTextSize(18); // was 28 -- too large for a small bubble
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(circleShape);
        bubbleView = bubble;

        // Size based on actual screen density (dp -> px) instead of a
        // raw pixel number, so it's a consistent, genuinely small
        // size across different phones rather than looking huge on
        // higher-density screens. 48dp is a standard, comfortable
        // touch-target size, not an oversized block.
        int bubbleSizePx = (int) (48 * getResources().getDisplayMetrics().density);

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        bubbleParams = new WindowManager.LayoutParams(
                bubbleSizePx, bubbleSizePx, // 48dp, converted to real pixels for this screen
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        bubbleParams.gravity = Gravity.TOP | Gravity.START;
        bubbleParams.x = 0;
        bubbleParams.y = 300;

        // Makes the bubble draggable anywhere on screen, and treats a
        // tap-without-drag as a click (currently just logs; will
        // expand the bubble to show call controls in a later step).
        bubbleView.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean isDragging = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = bubbleParams.x;
                        initialY = bubbleParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        isDragging = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int deltaX = (int) (event.getRawX() - initialTouchX);
                        int deltaY = (int) (event.getRawY() - initialTouchY);
                        if (Math.abs(deltaX) > 10 || Math.abs(deltaY) > 10) {
                            isDragging = true;
                        }
                        bubbleParams.x = initialX + deltaX;
                        bubbleParams.y = initialY + deltaY;
                        windowManager.updateViewLayout(bubbleView, bubbleParams);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!isDragging) {
                            togglePanel();
                        }
                        return true;
                }
                return false;
            }
        });

        windowManager.addView(bubbleView, bubbleParams);
    }

    // ---------------------------------------------------------------
    // Expandable panel: shown when the bubble is tapped (not dragged).
    // Small native Android UI, deliberately lightweight -- a code
    // input + Send button, plus a dynamic row that shows Accept/
    // Decline when a real request is ringing.
    // ---------------------------------------------------------------

    private void togglePanel() {
        if (isPanelShowing) {
            hidePanel();
        } else {
            showPanel();
        }
    }

    private void showPanel() {
        if (isPanelShowing) return;
        isPanelShowing = true;

        int pad = (int) (12 * getResources().getDisplayMetrics().density);
        int gap = (int) (8 * getResources().getDisplayMetrics().density);

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable panelBg = new GradientDrawable();
        panelBg.setColor(Color.parseColor("#131313"));
        panelBg.setStroke(2, Color.parseColor("#2a2a2a"));
        panelBg.setCornerRadius(16);
        panel.setBackground(panelBg);
        panel.setPadding(pad, pad, pad, pad);

        // Row 1: code input + send button.
        LinearLayout sendRow = new LinearLayout(this);
        sendRow.setOrientation(LinearLayout.HORIZONTAL);
        sendRow.setGravity(Gravity.CENTER_VERTICAL);

        codeInputField = new EditText(this);
        codeInputField.setHint("CODE");
        codeInputField.setHintTextColor(Color.parseColor("#666666"));
        codeInputField.setTextColor(Color.WHITE);
        codeInputField.setSingleLine(true);
        codeInputField.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.AllCaps(), new android.text.InputFilter.LengthFilter(4)});
        codeInputField.setBackgroundColor(Color.parseColor("#1a1a1a"));
        codeInputField.setPadding(pad, pad / 2, pad, pad / 2);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        inputLp.setMarginEnd(gap);
        codeInputField.setLayoutParams(inputLp);

        Button sendButton = new Button(this);
        sendButton.setText("Send");
        sendButton.setTextColor(Color.parseColor("#0a0a0a"));
        GradientDrawable sendBg = new GradientDrawable();
        sendBg.setColor(Color.parseColor("#3ddc97"));
        sendBg.setCornerRadius(8);
        sendButton.setBackground(sendBg);
        sendButton.setOnClickListener(v -> {
            String code = codeInputField.getText().toString().trim();
            if (code.length() == 4) {
                sendConnectionRequest(code);
            }
        });

        sendRow.addView(codeInputField);
        sendRow.addView(sendButton);

        // Row 2 (dynamic): populated with Accept/Decline only when a
        // request is actually ringing -- see updateBubbleAppearance,
        // which calls refreshPanelRequestRow() whenever state changes
        // while the panel happens to be open.
        requestStatusRow = new LinearLayout(this);
        requestStatusRow.setOrientation(LinearLayout.HORIZONTAL);
        requestStatusRow.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowLp.topMargin = gap;
        requestStatusRow.setLayoutParams(rowLp);

        panel.addView(sendRow);
        panel.addView(requestStatusRow);
        refreshPanelRequestRow();

        panelView = panel;

        int overlayType = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        int panelWidthPx = (int) (240 * getResources().getDisplayMetrics().density);

        panelParams = new WindowManager.LayoutParams(
                panelWidthPx,
                WindowManager.LayoutParams.WRAP_CONTENT,
                overlayType,
                // Focusable (unlike the bubble itself) so the code
                // input field can actually receive keyboard input.
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
        );
        panelParams.gravity = Gravity.TOP | Gravity.START;
        // Position the panel just below-right of wherever the bubble
        // currently is, rather than a fixed screen location.
        panelParams.x = bubbleParams.x;
        panelParams.y = bubbleParams.y + (int) (56 * getResources().getDisplayMetrics().density);

        windowManager.addView(panelView, panelParams);
    }

    private void hidePanel() {
        if (!isPanelShowing) return;
        isPanelShowing = false;

        // Dismiss the keyboard if it was up for the code field.
        if (codeInputField != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(codeInputField.getWindowToken(), 0);
        }

        if (panelView != null && windowManager != null) {
            windowManager.removeView(panelView);
        }
        panelView = null;
        codeInputField = null;
        requestStatusRow = null;
    }

    // Sends a connection request using the exact same backend
    // endpoint the main web app already uses (send-request) -- via
    // the hidden WebView's JS, since that's the only context with
    // both the real deviceId and a live fetch() able to reach your
    // Netlify functions with the right origin/cookies context.
    private void sendConnectionRequest(String targetCode) {
        String js = "(function() {"
                + "  if (window.sendRequestFromNative) {"
                + "    window.sendRequestFromNative('" + targetCode.replace("'", "") + "');"
                + "  }"
                + "})();";
        runOnWebView(js);
        android.widget.Toast.makeText(
                getApplicationContext(),
                "Request sent to " + targetCode,
                android.widget.Toast.LENGTH_SHORT
        ).show();
        if (codeInputField != null) codeInputField.setText("");
        hidePanel();
    }

    // Rebuilds the panel's dynamic Accept/Decline row to match
    // current state. Safe to call even when the panel isn't showing
    // (it just does nothing in that case).
    private void refreshPanelRequestRow() {
        if (requestStatusRow == null) return;
        requestStatusRow.removeAllViews();

        if (!"ringing".equals(currentCallState)) {
            return;
        }

        Button acceptBtn = new Button(this);
        acceptBtn.setText("Accept");
        acceptBtn.setTextColor(Color.parseColor("#0a0a0a"));
        GradientDrawable acceptBg = new GradientDrawable();
        acceptBg.setColor(Color.parseColor("#3ddc97"));
        acceptBg.setCornerRadius(8);
        acceptBtn.setBackground(acceptBg);
        acceptBtn.setOnClickListener(v -> respondToRingingRequest("accept"));

        Button declineBtn = new Button(this);
        declineBtn.setText("Decline");
        declineBtn.setTextColor(Color.WHITE);
        GradientDrawable declineBg = new GradientDrawable();
        declineBg.setColor(Color.parseColor("#ff5c5c"));
        declineBg.setCornerRadius(8);
        declineBtn.setBackground(declineBg);
        declineBtn.setOnClickListener(v -> respondToRingingRequest("decline"));

        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        int gap = (int) (8 * getResources().getDisplayMetrics().density);
        btnLp.setMarginEnd(gap);
        acceptBtn.setLayoutParams(btnLp);

        requestStatusRow.addView(acceptBtn);
        requestStatusRow.addView(declineBtn);
    }

    private void respondToRingingRequest(String response) {
        String js = "(function() {"
                + "  if (window.respondToRingingRequestFromNative) {"
                + "    window.respondToRingingRequestFromNative('" + response + "');"
                + "  }"
                + "})();";
        runOnWebView(js);
        hidePanel();
    }

    // Loads your real, existing PWA into an invisible WebView running
    // in the background. This is the actual bridge: the web app's
    // JavaScript (already built, already working) can call into
    // Android via bridgeToAndroid.*, and Android can call back into
    // the page's JS via evaluateJavascript(...) below.
    @SuppressLint("SetJavaScriptEnabled")
    private void setupHiddenWebView() {
        hiddenWebView = new WebView(this);

        WebSettings settings = hiddenWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true); // needed for localStorage (deviceId, session data)
        settings.setMediaPlaybackRequiresUserGesture(false); // needed for the ringtone / call audio to play without a tap

        hiddenWebView.addJavascriptInterface(new AndroidBridge(), "bridgeToAndroid");

        hiddenWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                // Inject the shared deviceId BEFORE the page's own
                // scripts run, so getOrCreateDeviceId() finds this
                // value already in localStorage instead of generating
                // its own separate one. This has to happen at
                // onPageStarted (before load completes), not
                // onPageFinished, or the page's own init code will
                // have already run first and created a different ID.
                String sharedDeviceId = getOrCreateSharedDeviceId();
                view.evaluateJavascript(
                        "localStorage.setItem('gamersChatDeviceId', '" + sharedDeviceId + "');",
                        null
                );
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                android.util.Log.i("VoxxChatBubble", "Site loaded successfully: " + url);
                clearOfflineIndicator();
                injectBridgeReadyFlag();

                // Chromium throttles/suspends a WebView's OWN
                // setInterval/setTimeout timers once it's treated as
                // backgrounded -- which our zero-size overlay WebView
                // always is, since it's genuinely never visible. This
                // silently broke the page's existing polling loop for
                // incoming requests. Driving the check from NATIVE
                // Android's Handler instead sidesteps that entirely,
                // since Android's own timers aren't subject to
                // Chromium's background-tab throttling rules.
                startNativeDrivenPolling();
            }

            @Override
            public void onReceivedError(WebView view, android.webkit.WebResourceRequest request,
                                          android.webkit.WebResourceError error) {
                super.onReceivedError(view, request, error);
                // No longer shows an intrusive Toast for this -- a
                // real network drop happens often enough (turning off
                // data, weak signal) that a popup every time was
                // genuinely bad UX. Logged silently instead, and the
                // bubble itself dims to indicate something's wrong,
                // which is a much less disruptive signal.
                android.util.Log.w("VoxxChatBubble", "Site failed to load: " + error.getDescription());
                showOfflineIndicator();
            }
        });

        hiddenWebView.loadUrl(getString(R.string.twa_launch_url));

        // Attach it to the window manager with zero visible size --
        // present in the view hierarchy (so it isn't paused as
        // aggressively as a fully detached WebView) but genuinely
        // invisible to the user.
        WindowManager.LayoutParams hiddenParams = new WindowManager.LayoutParams(
                1, 1,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
        );
        hiddenParams.gravity = Gravity.TOP | Gravity.START;
        windowManager.addView(hiddenWebView, hiddenParams);
    }

    // A small, deliberately simple marker so the web page's own JS
    // can detect "I'm running inside the native bubble service" and
    // adjust behavior if useful later (e.g. skip showing its own
    // install banner).
    private void injectBridgeReadyFlag() {
        runOnWebView("window.__voxxBubbleBridgeReady = true;");
    }

    private final Handler nativePollingHandler = new Handler(Looper.getMainLooper());
    private boolean nativePollingStarted = false;

    // Repeatedly calls the page's own incoming-request check function
    // every 3 seconds, driven by Android's Handler (not the page's own
    // setInterval, which gets throttled once the WebView is treated
    // as backgrounded). Requires the web app to expose a
    // window.checkIncomingRequestsNow() function -- see the
    // corresponding index.html change.
    private void startNativeDrivenPolling() {
        if (nativePollingStarted) return;
        nativePollingStarted = true;

        Runnable pollTask = new Runnable() {
            @Override
            public void run() {
                runOnWebView("if (window.checkIncomingRequestsNow) { window.checkIncomingRequestsNow(); }");
                nativePollingHandler.postDelayed(this, 3000);
            }
        };
        nativePollingHandler.post(pollTask);
    }

    private void runOnWebView(String js) {
        new Handler(Looper.getMainLooper()).post(() -> {
            if (hiddenWebView != null) {
                hiddenWebView.evaluateJavascript(js, null);
            }
        });
    }

    // The actual bridge object exposed to the page's JavaScript as
    // `window.bridgeToAndroid`. Methods here are deliberately small
    // and specific -- each one is a single fact the web app already
    // knows and needs to hand to native code, not a general-purpose
    // remote-control surface.
    private class AndroidBridge {

        // Called by the PWA's JS whenever call state changes (idle,
        // an incoming request is ringing, or a call is actively
        // connected). Runs on a background JS thread, so we hop back
        // to the main thread before touching any UI.
        @JavascriptInterface
        public void updateBubbleState(String state) {
            currentCallState = state;
            new Handler(Looper.getMainLooper()).post(() -> {
                android.util.Log.i("VoxxChatBubble", "State changed to " + state);
                updateBubbleAppearance(state);
            });
        }
    }

    // Changes the bubble's color/icon to reflect real call state,
    // called from the JS bridge above. Kept separate from
    // showBubble()'s initial creation so it can be called repeatedly
    // without recreating the whole view.
    private void updateBubbleAppearance(String state) {
        if (!(bubbleView instanceof TextView)) return;
        TextView bubble = (TextView) bubbleView;

        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.OVAL);

        switch (state) {
            case "ringing":
                shape.setColor(Color.parseColor("#ff8c42")); // orange -- matches incoming-request color elsewhere in the app
                bubble.setText("📞");
                break;
            case "in_call":
                shape.setColor(Color.parseColor("#3ddc97")); // mint -- active call
                bubble.setText("🎙️");
                break;
            default: // idle
                shape.setColor(Color.parseColor("#444444")); // dim gray -- nothing happening
                bubble.setText("🎙️");
                break;
        }
        bubble.setBackground(shape);

        // Keep the panel's Accept/Decline row in sync if it happens
        // to be open right now (e.g. a request arrives while the
        // person already has the panel expanded for another reason).
        refreshPanelRequestRow();
    }

    private boolean isShowingOfflineIndicator = false;

    // Dims the bubble (semi-transparent) to indicate a real connection
    // problem, instead of the previous intrusive Toast popup that
    // appeared every time the person's data connection dropped.
    private void showOfflineIndicator() {
        if (isShowingOfflineIndicator) return;
        isShowingOfflineIndicator = true;
        if (bubbleView != null) {
            bubbleView.setAlpha(0.4f);
        }
    }

    private void clearOfflineIndicator() {
        if (!isShowingOfflineIndicator) return;
        isShowingOfflineIndicator = false;
        if (bubbleView != null) {
            bubbleView.setAlpha(1.0f);
        }
    }

    private Notification buildForegroundNotification() {
        Intent notificationIntent = new Intent(this, OverlayPermissionActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this, 0, notificationIntent,
                PendingIntent.FLAG_IMMUTABLE
        );

        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Voxx Chat bubble active")
                .setContentText("Tap to manage the floating bubble.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pendingIntent)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Voxx Chat Bubble",
                    NotificationManager.IMPORTANCE_LOW // low = no sound/vibration, just persistent
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        nativePollingHandler.removeCallbacksAndMessages(null);
        if (panelView != null && windowManager != null) {
            windowManager.removeView(panelView);
            panelView = null;
        }
        if (bubbleView != null && windowManager != null) {
            windowManager.removeView(bubbleView);
            bubbleView = null;
        }
        if (hiddenWebView != null && windowManager != null) {
            windowManager.removeView(hiddenWebView);
            hiddenWebView.destroy();
            hiddenWebView = null;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null; // Not a bindable service -- only started/stopped.
    }
}
